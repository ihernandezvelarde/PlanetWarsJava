package PlanetWars;

import java.io.IOException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;



public class ConnectionBDD {
	private Connection conex;
	String url;
	String user;
	String password;
	public ConnectionBDD() {
		// Carga el driver de oracle
       try {
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		// Conecta con la base de datos orcl con el usuario system y la contrasea password
        conex = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCLEBASE", "PLANETWARS", "PLANETWARS");
		System.out.println("Conectado MAQUINAAA");
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		//e.printStackTrace();
		System.out.println("Error de conexion");
	}	
	}
	public Connection getConex() {
		return conex;
	}
	
}
class InfoShips  {
	CallableStatement getInfoShips(Connection con, int id_nave) {
		CallableStatement cst = null;
		try {
			cst = con.prepareCall("{call GETSHIP (?,?,?,?,?,?,?,?,?,?)}");
			 // Parametro 1 del procedimiento almacenado
            cst.setInt(1, id_nave);
            
            // Definimos los tipos de los parametros de salida del procedimiento almacenado
            cst.registerOutParameter(2, java.sql.Types.VARCHAR);
            cst.registerOutParameter(3, java.sql.Types.INTEGER);
            cst.registerOutParameter(4, java.sql.Types.INTEGER);
            cst.registerOutParameter(5, java.sql.Types.INTEGER);
            cst.registerOutParameter(6, java.sql.Types.INTEGER);
            cst.registerOutParameter(7, java.sql.Types.INTEGER);
            cst.registerOutParameter(8, java.sql.Types.INTEGER);
            cst.registerOutParameter(9, java.sql.Types.INTEGER);
            cst.registerOutParameter(10, java.sql.Types.INTEGER); 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	return cst;
	}
	
}
class InfoDefense {
	CallableStatement getInfoDefense(Connection con, int id_nave) {
		
		return null;
		}
}
