package PlanetWars;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import javax.swing.Timer;

public class Main {

	public static void main(String[] args) {
		ConnectionBDD c = new ConnectionBDD();
		
		Connection con= c.getConex();
		InfoShips info=new InfoShips();
		ArmoredShip a = new ArmoredShip(1, 1, con);
		System.out.println(a.getMetalCost());
		Planet p=new Planet();
		VentanaInicial ventanita=new VentanaInicial(con);
		//VentanaLogin v = new VentanaLogin(con);
		
		Timer timer = new Timer (1000, new ActionListener ()
		{
		    public void actionPerformed(ActionEvent e)
		    {
		        // Aqu� el c�digo que queramos ejecutar.
		    	p.setDeuterium(p.getDeuterium()+10);
		    	p.setMetal(p.getMetal()+10);
		    	ventanita.aumentadorRecursos(p.getMetal(), p.getDeuterium());
		     }
		});
		timer.start();
		//p.upgradeTechnologyDefense();
	}
}
