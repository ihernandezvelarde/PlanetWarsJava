package PlanetWars;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class PlasmaCannon extends Defense implements MilitaryUnit{

    PlasmaCannon(int tecnoDefense, int tecnoAtack,Connection con) {
        super.setInitialArmor(ARMOR_MISSILELAUNCHER);
        super.setBaseDamage(BASE_DAMAGE_MISSILELAUNCHER);
        super.setArmor(ARMOR_MISSILELAUNCHER);
        InfoDefense def=new InfoDefense();
        CallableStatement resultado=def.getInfoDefense(con,1);
        try {
			resultado.getInt(0);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    @Override
    public int attack() {return this.getBaseDamage();}

    @Override
    public void takeDamage(int receivedDamage) {this.setArmor(this.getActualArmor() - receivedDamage);}

    @Override
    public int getActualArmor() {return this.getArmor();}

    @Override
    public int getChanceAttackAgain() {return this.CHANCE_ATTACK_AGAIN_PLASMACANNON;}

    public void changeStatsByTech(int techArmor,int techDamage){
        this.setBaseDamage(BASE_DAMAGE_PLASMACANNON + (techDamage * PLUS_ATTACK_PLASMACANNON_BY_TECHNOLOGY)*BASE_DAMAGE_PLASMACANNON/100);
        this.setInitialArmor(ARMOR_PLASMACANNON + (techArmor * PLUS_ARMOR_PLASMACANNON_BY_TECHNOLOGY)*ARMOR_PLASMACANNON/100);
    }

	@Override
	public int getMetalCost(Connection con) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getDeuteriumCost(Connection con) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getChanceGeneratinWaste(Connection con) {
		// TODO Auto-generated method stub
		return 0;
	}
}