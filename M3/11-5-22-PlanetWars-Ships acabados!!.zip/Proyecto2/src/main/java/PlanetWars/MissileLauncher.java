package PlanetWars;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

public class MissileLauncher extends Defense implements MilitaryUnit{

    MissileLauncher(int tecnoDefense, int tecnoAtack,Connection con) {
        super.setInitialArmor(ARMOR_MISSILELAUNCHER);
        super.setBaseDamage(BASE_DAMAGE_MISSILELAUNCHER);
        super.setArmor(ARMOR_MISSILELAUNCHER);
        InfoDefense def=new InfoDefense();
        CallableStatement resultado=def.getInfoDefense(con,1);
        try {
			resultado.getInt(0);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    @Override
    public int attack() {return this.getBaseDamage();}

    @Override
    public void takeDamage(int receivedDamage) {
        this.setArmor(this.getActualArmor() - receivedDamage);
    }

    @Override
    public int getActualArmor() {return this.getArmor();}

    @Override
    public int getChanceAttackAgain() {return this.CHANCE_ATTACK_AGAIN_MISSILELAUNCHER;}

   

	@Override
	public int getMetalCost(Connection con) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getDeuteriumCost(Connection con) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int getChanceGeneratinWaste(Connection con) {
		// TODO Auto-generated method stub
		return 0;
	}
}
