package PlanetWars;

import java.sql.Connection;
import java.util.ArrayList;

public class Enemy {
	
	ArrayList<MilitaryUnit>[] enemyArmy = new ArrayList[4];
	
	public Enemy(Connection con) {
		enemyArmy[0] = addLightHunters(con);
		enemyArmy[1] = addHeavyHunters(con);
		enemyArmy[2] = addBattleShips(con);
		enemyArmy[3] = addArmoredShips(con);
		
	}
	
	public ArrayList<MilitaryUnit>[] getEnemyArmy() {
		return enemyArmy;
	}
	
	private ArrayList<MilitaryUnit> addLightHunters(Connection con) {
		ArrayList<MilitaryUnit> lightHunters = new ArrayList<MilitaryUnit>();
		int[] num_units = new int[5];
		// total de 30 unidades que se reparten aleatoriamente en grupos de diferentes niveles de tecnologia
		num_units[0] = (int) (Math.random()*30);
		num_units[1] = (int) (Math.random()*(30-num_units[0]));
		num_units[2] = (int) (Math.random()*(30-num_units[1]-num_units[0]));
		num_units[3] = (int) (Math.random()*(30-num_units[2]-num_units[1]-num_units[0]));
		num_units[4] = (int) (Math.random()*(30-num_units[3]-num_units[2]-num_units[1]-num_units[0]));
		
		for (int i = 0; i < num_units.length; i++) {
			for (int j = 1; j <= num_units[i]; j++) {
				lightHunters.add(new LightHunter(i, i, con));
			}
		}
		return lightHunters;
	}
	
	private ArrayList<MilitaryUnit> addHeavyHunters(Connection con) {
		ArrayList<MilitaryUnit> heavyHunters = new ArrayList<MilitaryUnit>();
		int[] num_units = new int[5];
		// total de 15 unidades que se reparten aleatoriamente en grupos de diferentes niveles de tecnologia
		num_units[0] = (int) (Math.random()*15);
		num_units[1] = (int) (Math.random()*(15-num_units[0]));
		num_units[2] = (int) (Math.random()*(15-num_units[1]-num_units[0]));
		num_units[3] = (int) (Math.random()*(15-num_units[2]-num_units[1]-num_units[0]));
		num_units[4] = (int) (Math.random()*(15-num_units[3]-num_units[2]-num_units[1]-num_units[0]));
		
		for (int i = 0; i < num_units.length; i++) {
			for (int j = 1; j <= num_units[i]; j++) {
				heavyHunters.add(new HeavyHunter(i, i, con));
			}
		}
		return heavyHunters;
	}
	
	private ArrayList<MilitaryUnit> addBattleShips(Connection con) {
		ArrayList<MilitaryUnit> battleShips = new ArrayList<MilitaryUnit>();
		int[] num_units = new int[5];
		// total de 6 unidades que se reparten aleatoriamente en grupos de diferentes niveles de tecnologia
		num_units[0] = (int) (Math.random()*6);
		num_units[1] = (int) (Math.random()*(6-num_units[0]));
		num_units[2] = (int) (Math.random()*(6-num_units[1]-num_units[0]));
		num_units[3] = (int) (Math.random()*(6-num_units[2]-num_units[1]-num_units[0]));
		num_units[4] = (int) (Math.random()*(6-num_units[3]-num_units[2]-num_units[1]-num_units[0]));
		
		for (int i = 0; i < num_units.length; i++) {
			for (int j = 1; j <= num_units[i]; j++) {
				battleShips.add(new BattleShip(i, i, con));
			}
		}
		return battleShips;
	}
	
	private ArrayList<MilitaryUnit> addArmoredShips(Connection con) {
		ArrayList<MilitaryUnit> armoredShips = new ArrayList<MilitaryUnit>();
		int[] num_units = new int[5];
		// total de 3 unidades que se reparten aleatoriamente en grupos de diferentes niveles de tecnologia
		num_units[0] = (int) (Math.random()*3);
		num_units[1] = (int) (Math.random()*(3-num_units[0]));
		num_units[2] = (int) (Math.random()*(3-num_units[1]-num_units[0]));
		num_units[3] = (int) (Math.random()*(3-num_units[2]-num_units[1]-num_units[0]));
		num_units[4] = (int) (Math.random()*(3-num_units[3]-num_units[2]-num_units[1]-num_units[0]));
		
		for (int i = 0; i < num_units.length; i++) {
			for (int j = 1; j <= num_units[i]; j++) {
				armoredShips.add(new ArmoredShip(i, i, con));
			}
		}
		return armoredShips;
	}
}
