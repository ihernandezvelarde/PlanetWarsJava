package PlanetWars;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

//extends Ship
public class LightHunter extends Ship implements Variables, MilitaryUnit{
	CallableStatement cst;
    public LightHunter(int tecnoDefense, int tecnoAtack,Connection con) {
    	InfoShips ship=new InfoShips();
    	cst= ship.getInfoShips(con, 4);
    	try {
			cst.execute();
			super.setInitialArmor(cst.getInt(6));
			super.setBaseDamage(cst.getInt(8));
	        this.setArmor(this.getInitialArmor() + (tecnoDefense*PLUS_ARMOR_LIGTHHUNTER_BY_TECHNOLOGY)*this.getInitialArmor()/100);
	        this.setBaseDamage(this.getBaseDamage()+(tecnoAtack*PLUS_ATTACK_LIGTHHUNTER_BY_TECHNOLOGY)*this.getBaseDamage()/100);
	        cst.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
//    	super.setInitialArmor(ARMOR_LIGTHHUNTER);
//        super.setBaseDamage(BASE_DAMAGE_LIGTHHUNTER);
//        this.setArmor(ARMOR_LIGTHHUNTER + (tecnoDefense*PLUS_ARMOR_LIGTHHUNTER_BY_TECHNOLOGY)*ARMOR_LIGTHHUNTER/100);
//        this.setBaseDamage(BASE_DAMAGE_LIGTHHUNTER+(tecnoAtack*PLUS_ATTACK_LIGTHHUNTER_BY_TECHNOLOGY)*BASE_DAMAGE_LIGTHHUNTER/100);

    }
    @Override
    public void takeDamage(int receivedDamage) {
        this.setArmor(this.getArmor()-receivedDamage);        
    }
    @Override
    public int getMetalCost() {
        // TODO Auto-generated method stub
    	
         try {
			return cst.getInt(3);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			return 0;
		}    
    }
    @Override
    public int getDeuteriumCost() {
        // TODO Auto-generated method stub
    	try {
			return cst.getInt(5);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			return 0;
		}    
    }
    @Override
    public int getChanceGeneratinWaste() {
        // TODO Auto-generated method stub
    	try {
			return cst.getInt(10);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			return 0;
		}    
    }
    @Override
    public int getChanceAttackAgain() {
        // TODO Auto-generated method stub
    return this.CHANCE_ATTACK_AGAIN_LIGTHHUNTER;    
    }
    
   
}